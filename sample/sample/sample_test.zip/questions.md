# Question 1

What is the unit of electric charge?

* Coulomb
* Ampere
* Volt
* Watt

---

# Question 2

Which of the following is a vector quantity?

* Mass
* Time
* Velocity
* Temperature

---

# Question 3

What is the value of gravitational acceleration on Earth?

* 9.8 m/s²
* 9.8 m/s
* 9.8 m²/s
* 9.8 s²/m

---

# Question 4

Which law states that the rate of change of momentum is directly proportional to the applied force?

* Newton's First Law
* Newton's Second Law
* Newton's Third Law
* Law of Conservation of Momentum

---

# Question 5

What is the SI unit of power?

* Joule
* Newton
* Watt
* Pascal

---

# Question 6

Which of the following is NOT a fundamental force?

* Gravitational Force
* Electromagnetic Force
* Strong Nuclear Force
* Frictional Force

---

# Question 7

What is the dimensional formula of force?

* [M L T⁻²]
* [M L² T⁻²]
* [M L T⁻¹]
* [M L² T⁻¹]

---

# Question 8

Which of the following is a scalar quantity?

* Displacement
* Acceleration
* Speed
* Force

---

# Question 9

What is the SI unit of electric current?

* Coulomb
* Volt
* Ohm
* Ampere

---

# Question 10

Which law states that the algebraic sum of currents at any node is zero?

* Kirchhoff's Current Law
* Kirchhoff's Voltage Law
* Ohm's Law
* Coulomb's Law
